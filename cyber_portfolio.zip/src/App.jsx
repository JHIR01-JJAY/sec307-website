import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Footer from './components/Footer'

import Home from './pages/Home'
import CyberPredators from './pages/CyberPredators'
import VictimStories from './pages/VictimStories'
import CrimeImpact from './pages/CrimeImpact'
import Laws from './pages/Laws'
import Help from './pages/Help'

function App() {
  return (
    <Router>
      <Navbar />
      <div className="content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/cyber-predators" element={<CyberPredators />} />
          <Route path="/victim-stories" element={<VictimStories />} />
          <Route path="/crime-impact" element={<CrimeImpact />} />
          <Route path="/laws" element={<Laws />} />
          <Route path="/help" element={<Help />} />
        </Routes>
      </div>
      <Footer />
    </Router>
  )
}

export default App
